# MODIFICATIONS

このディレクトリ (`MyPocketOS-Fluent-yellow`) は、以下upstreamプロジェクトの
生成結果を元にした **MyPocketOS向け派生サブセット** です。
upstreamの完全版をそのまま収録したものではありません。

## upstream

- Project: Fluent Icon Theme
- URL: https://github.com/vinceliuice/Fluent-icon-theme
- Tag: `2026-07-27`
- Commit: `c70c2441bcf2ab8bbc267e55635c76d69f659a8b`
- upstream tarball SHA-256 (このサブセットの生成に使用した入力): `7fdd60faa543b297ef2d4f3d083d8b382e59a9b0933cbb1dfc042539d45036e2`
- License: GPL-3.0 (同梱の `COPYING` に全文。upstream原文のまま無改変)

## このサブセットの生成日

2026-08-29

## MyPocketOSによる変更点

- `install.sh yellow` の生成結果 (標準明度の `Fluent-yellow`) のみを対象とした。
  light/dark明度バリエーションは対象外。
- テーマ名を `Fluent-yellow` から **`MyPocketOS-Fluent-yellow`** へ変更した
  (`index.theme` の `Name=`、ディレクトリ名とも)。
- `index.theme` を書き換えた。`Directories=` および各セクションを、
  実際に収録する `scalable/`・`symbolic/` 配下のディレクトリのみに
  限定した (存在しない固定サイズ・HiDPIディレクトリへの参照を削除)。
- 色共通アイコンを指す隠しディレクトリ (`.Fluent-base` 等) への
  シンボリックリンクを、実ファイルへ実体化 (dereference) し、単体で
  自己完結するようにした。
- 以下の固定サイズ・HiDPIディレクトリを削除した
  (`scalable`/`symbolic` は Type=Scalable のため、削除したサイズと
  同じアイコンを任意の解像度で描画できる)。

  - `16`
  - `16@2x`
  - `16@3x`
  - `22`
  - `22@2x`
  - `22@3x`
  - `24`
  - `24@2x`
  - `24@3x`
  - `32`
  - `32@2x`
  - `32@3x`
  - `256`
  - `256@2x`
  - `256@3x`
  - `scalable@2x`
  - `scalable@3x`

- 生成過程で作られる `icon-theme.cache` を削除した
  (MyPocketOSのビルドパイプラインは配布物へアイコンキャッシュを
  含めない方針のため。ビルド時に別途生成されない)。
- 以下、ファイル名が不正 (拡張子欠落・破損) なためアイコン名として
  解決されず、実質的に無効なファイル3件をサブセットから除外した
  (upstream生成結果の時点で既にこの名前であり、MyPocketOSが破損
  させたものではない)。

  - `scalable/apps/cinnamon-virtual-keyboard`
  - `scalable/apps/org.gnome.Weather.Application.svg}`
  - `scalable/apps/page.kramo.Cartridges`

## 変更していないもの

- `scalable/`・`symbolic/` 配下のSVGファイル自体の内容 (上記3件の
  除外を除き、upstream生成結果とバイト完全一致)。
- `COPYING` (upstream原文のまま)。
